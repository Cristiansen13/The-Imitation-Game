# Create a 3-node Swarm cluster for the Imitation Game project

This script creates one manager VM and two worker VMs by cloning a prepared Hyper-V VHDX image, starts them, waits for IP addresses, joins the workers to Swarm, and prints the resulting node list.

## Prerequisites

- Windows Pro / Enterprise with Hyper-V management tools installed
- PowerShell started as Administrator
- An external Hyper-V virtual switch, or a physical adapter name so the script can create one
- A generalized Linux VHDX image with:
  - SSH server enabled
  - Docker already installed
  - a user account with SSH access and permission to run `docker`

## Example

```powershell
.\scripts\create-swarm-cluster.ps1 `
  -BaseVhdxPath C:\Images\ubuntu-template.vhdx `
  -PhysicalAdapterName "Ethernet" `
  -GuestUser ubuntu `
  -GuestSshKeyPath C:\Users\User\.ssh\id_rsa
```

If the manager IP needs to be forced, pass `-ManagerAdvertiseAddress <ip>`.
