[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path $_ })]
    [string]$BaseVhdxPath,

    [Parameter(Mandatory = $false)]
    [string]$VirtualSwitchName = 'ImitationGame-Switch',

    [Parameter(Mandatory = $false)]
    [string]$PhysicalAdapterName,

    [Parameter(Mandatory = $false)]
    [string]$VmRootPath = 'C:\Hyper-V\ImitationGame',

    [Parameter(Mandatory = $false)]
    [string]$ManagerVmName = 'imitation-game-manager',

    [Parameter(Mandatory = $false)]
    [string]$Worker1VmName = 'imitation-game-worker-1',

    [Parameter(Mandatory = $false)]
    [string]$Worker2VmName = 'imitation-game-worker-2',

    [Parameter(Mandatory = $false)]
    [string]$GuestUser = 'ubuntu',

    [Parameter(Mandatory = $false)]
    [string]$GuestSshKeyPath,

    [Parameter(Mandatory = $false)]
    [int]$MemoryStartupGB = 4,

    [Parameter(Mandatory = $false)]
    [int]$ProcessorCount = 2,

    [Parameter(Mandatory = $false)]
    [int]$NetworkWaitSeconds = 600,

    [Parameter(Mandatory = $false)]
    [int]$SshWaitSeconds = 600,

    [Parameter(Mandatory = $false)]
    [string]$ManagerAdvertiseAddress
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Assert-RunningAsAdministrator {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($currentIdentity)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if (-not $isAdmin) {
        throw 'Run this script from an elevated PowerShell session.'
    }
}

function Import-HyperVModule {
    if (-not (Get-Module -ListAvailable -Name Hyper-V)) {
        throw 'The Hyper-V module is not installed on this machine. Install the Hyper-V management tools and rerun the script.'
    }

    Import-Module Hyper-V
}

function Ensure-VirtualSwitch {
    param(
        [string]$Name,
        [string]$AdapterName
    )

    $switch = Get-VMSwitch -Name $Name -ErrorAction SilentlyContinue
    if ($switch) {
        return $switch
    }

    if ([string]::IsNullOrWhiteSpace($AdapterName)) {
        throw "Virtual switch '$Name' does not exist. Provide -PhysicalAdapterName to create an external switch, or create '$Name' manually first."
    }

    if ($PSCmdlet.ShouldProcess("VMSwitch $Name", "Create external switch on adapter $AdapterName")) {
        return New-VMSwitch -Name $Name -NetAdapterName $AdapterName -AllowManagementOS $true
    }
}

function New-ClusterVm {
    param(
        [string]$Name,
        [string]$BaseDisk,
        [string]$RootPath,
        [string]$SwitchName,
        [int]$MemoryGB,
        [int]$CpuCount
    )

    $vmPath = Join-Path $RootPath $Name
    $diskExtension = [IO.Path]::GetExtension($BaseDisk)
    if ([string]::IsNullOrWhiteSpace($diskExtension)) {
        $diskExtension = '.vhdx'
    }

    $generation = 2
    if ($diskExtension -ieq '.vhd') {
        $generation = 1
    }

    $vhdPath = Join-Path $vmPath ("disk$diskExtension")

    $existingVm = Get-VM -Name $Name -ErrorAction SilentlyContinue
    if ($existingVm) {
        Remove-VM -Name $Name -Force -ErrorAction SilentlyContinue
    }

    if (Test-Path $vmPath) {
        Remove-Item -Path $vmPath -Recurse -Force
    }

    if (Test-Path $vmPath) {
        throw "VM path '$vmPath' already exists. Remove the existing VM or choose another name."
    }

    New-Item -ItemType Directory -Path $vmPath -Force | Out-Null
    Copy-Item -Path $BaseDisk -Destination $vhdPath

    if ($PSCmdlet.ShouldProcess($Name, 'Create Hyper-V VM')) {
        New-VM -Name $Name -Generation $generation -VHDPath $vhdPath -Path $vmPath -SwitchName $SwitchName | Out-Null
        Set-VMMemory -VMName $Name -StartupBytes ($MemoryGB * 1GB)
        Set-VMProcessor -VMName $Name -Count $CpuCount
        Set-VM -VMName $Name -AutomaticStopAction ShutDown | Out-Null
    }
}

function Discover-VmAddressViaSsh {
    param(
        [string]$HostName,
        [string]$UserName,
        [string]$SshKeyPath,
        [string[]]$CandidateIps,
        [int]$TimeoutSeconds
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        foreach ($ip in $CandidateIps) {
            try {
                $result = & ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL -i $SshKeyPath "$UserName@$ip" 'hostname' 2>$null
                if ($LASTEXITCODE -eq 0 -and $result -like "*$HostName*") {
                    Write-Step "Discovered '$HostName' at $ip via SSH"
                    return $ip
                }
            }
            catch { }
        }

        Start-Sleep -Seconds 2
    }

    throw "Could not discover address for '$HostName' via SSH within ${TimeoutSeconds}s on IPs: $($CandidateIps -join ', ')"
}

function Test-SshCommandAvailability {
    if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
        throw 'OpenSSH client is not installed or is not on PATH. Install it before running this script.'
    }
}

function Invoke-SshCommand {
    param(
        [string]$HostAddress,
        [string]$UserName,
        [string]$Command,
        [string]$KeyPath
    )

    $sshArgs = @('-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=NUL')
    if (-not [string]::IsNullOrWhiteSpace($KeyPath)) {
        $sshArgs += @('-i', $KeyPath)
    }

    $sshArgs += "$UserName@$HostAddress"
    $sshArgs += $Command

    & ssh @sshArgs
    if ($LASTEXITCODE -ne 0) {
        throw "SSH command failed for $UserName@$HostAddress."
    }
}

function Write-Step {
    param([string]$Message)
    Write-Host "[swarm] $Message"
}

function Remove-StaleVmArtifacts {
    param(
        [string]$Name,
        [string]$VmPath
    )

    $existingVm = Get-VM -Name $Name -ErrorAction SilentlyContinue
    if ($existingVm) {
        Stop-VM -Name $Name -TurnOff -Force -ErrorAction SilentlyContinue | Out-Null
        Remove-VM -Name $Name -Force -ErrorAction SilentlyContinue
    }

    if (-not (Test-Path $VmPath)) {
        return
    }

    for ($attempt = 1; $attempt -le 12; $attempt++) {
        try {
            Remove-Item -Path $VmPath -Recurse -Force -ErrorAction Stop
            return
        }
        catch {
            if ($attempt -eq 12) {
                throw
            }

            Start-Sleep -Seconds 2
        }
    }
}

function New-ClusterVm {
    param(
        [string]$Name,
        [string]$BaseDisk,
        [string]$RootPath,
        [string]$SwitchName,
        [int]$MemoryGB,
        [int]$CpuCount
    )

    $vmPath = Join-Path $RootPath $Name
    $diskExtension = [IO.Path]::GetExtension($BaseDisk)
    if ([string]::IsNullOrWhiteSpace($diskExtension)) {
        $diskExtension = '.vhdx'
    }

    $generation = 2
    if ($diskExtension -ieq '.vhd') {
        $generation = 1
    }

    $vhdPath = Join-Path $vmPath ("disk$diskExtension")

    Remove-StaleVmArtifacts -Name $Name -VmPath $vmPath

    if (Test-Path $vmPath) {
        throw "VM path '$vmPath' already exists after cleanup. Remove the existing VM or choose another name."
    }

    New-Item -ItemType Directory -Path $vmPath -Force | Out-Null
    Copy-Item -Path $BaseDisk -Destination $vhdPath

    if ($PSCmdlet.ShouldProcess($Name, 'Create Hyper-V VM')) {
        New-VM -Name $Name -Generation $generation -VHDPath $vhdPath -Path $vmPath -SwitchName $SwitchName | Out-Null
        Set-VMMemory -VMName $Name -StartupBytes ($MemoryGB * 1GB)
        Set-VMProcessor -VMName $Name -Count $CpuCount
        Set-VM -VMName $Name -AutomaticStopAction ShutDown | Out-Null
    }
}

Assert-RunningAsAdministrator
Import-HyperVModule
Test-SshCommandAvailability

Write-Step "Prerequisites verified"

if (-not (Test-Path $BaseVhdxPath)) {
    throw "Base VHDX '$BaseVhdxPath' was not found."
}

if (-not [string]::IsNullOrWhiteSpace($GuestSshKeyPath) -and -not (Test-Path $GuestSshKeyPath)) {
    throw "SSH key '$GuestSshKeyPath' was not found."
}

New-Item -ItemType Directory -Path $VmRootPath -Force | Out-Null
Write-Step "Ensuring virtual switch '$VirtualSwitchName' exists"
$clusterSwitch = Ensure-VirtualSwitch -Name $VirtualSwitchName -AdapterName $PhysicalAdapterName

$vmDefinitions = @(
    @{ Name = $ManagerVmName },
    @{ Name = $Worker1VmName },
    @{ Name = $Worker2VmName }
)

foreach ($vm in $vmDefinitions) {
    Write-Step "Creating VM '$($vm.Name)'"
    New-ClusterVm -Name $vm.Name -BaseDisk $BaseVhdxPath -RootPath $VmRootPath -SwitchName $clusterSwitch.Name -MemoryGB $MemoryStartupGB -CpuCount $ProcessorCount
}

foreach ($vm in $vmDefinitions) {
    Write-Step "Starting VM '$($vm.Name)'"
    Start-VM -Name $vm.Name | Out-Null
}

Write-Step 'Discovering VM addresses via SSH probes'

$candidateIps = @(
    '169.254.1.1', '169.254.1.2', '169.254.1.3', '169.254.1.4', '169.254.1.5',
    '169.254.105.62', '169.254.105.63', '169.254.105.64', '169.254.105.65',
    '172.23.160.10', '172.23.160.20', '172.23.160.30',
    '10.0.0.10', '10.0.0.20', '10.0.0.30', '192.168.1.10', '192.168.1.20', '192.168.1.30'
)

$managerIp = Discover-VmAddressViaSsh -HostName $ManagerVmName -UserName $GuestUser -SshKeyPath $GuestSshKeyPath -CandidateIps $candidateIps -TimeoutSeconds 180
$worker1Ip = Discover-VmAddressViaSsh -HostName $Worker1VmName -UserName $GuestUser -SshKeyPath $GuestSshKeyPath -CandidateIps $candidateIps -TimeoutSeconds 180
$worker2Ip = Discover-VmAddressViaSsh -HostName $Worker2VmName -UserName $GuestUser -SshKeyPath $GuestSshKeyPath -CandidateIps $candidateIps -TimeoutSeconds 180

if ([string]::IsNullOrWhiteSpace($ManagerAdvertiseAddress)) {
    $ManagerAdvertiseAddress = $managerIp
}

Write-Host "Manager IP: $managerIp"
Write-Host "Worker 1 IP: $worker1Ip"
Write-Host "Worker 2 IP: $worker2Ip"

$dockerCheckCommand = 'docker info >/dev/null 2>&1'
Write-Step 'Checking Docker availability inside guests'
Invoke-SshCommand -HostAddress $managerIp -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command $dockerCheckCommand
Invoke-SshCommand -HostAddress $worker1Ip -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command $dockerCheckCommand
Invoke-SshCommand -HostAddress $worker2Ip -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command $dockerCheckCommand

Write-Step 'Initializing swarm on manager'
Invoke-SshCommand -HostAddress $managerIp -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command "docker swarm init --advertise-addr $ManagerAdvertiseAddress"
Write-Step 'Fetching worker join token'
$workerJoinToken = Invoke-SshCommand -HostAddress $managerIp -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command 'docker swarm join-token -q worker'
$workerJoinToken = ($workerJoinToken | Select-Object -First 1).Trim()

$workerJoinCommand = "docker swarm join --token $workerJoinToken $ManagerAdvertiseAddress:2377"
Write-Step 'Joining worker 1'
Invoke-SshCommand -HostAddress $worker1Ip -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command $workerJoinCommand
Write-Step 'Joining worker 2'
Invoke-SshCommand -HostAddress $worker2Ip -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command $workerJoinCommand

Write-Step 'Listing swarm nodes'
Invoke-SshCommand -HostAddress $managerIp -UserName $GuestUser -KeyPath $GuestSshKeyPath -Command 'docker node ls'
